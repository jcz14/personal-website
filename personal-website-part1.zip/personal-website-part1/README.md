This is my personal website. A live version can be found [here](http://jcz95.dynu.com/~jim/WmGXQ5YvdzSYCG8l/).

Currently uses HTML, CSS, and JavaScript. PHP and database functionality will be added in the next major revision. Page design and layout may change as well.

